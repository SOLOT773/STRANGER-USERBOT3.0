""" SpamX - Version """
__version__ = "v0.6"
