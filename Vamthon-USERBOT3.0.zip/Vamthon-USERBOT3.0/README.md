<p align="center"><a href="https://t.me/S_OL_O7"><img src="https://files.catbox.moe/e52u4b.png"></a></p>   
  
  <h6 align="center">   
     <b>• 𝗩𝗔𝗠𝗧𝗛𝗢𝗡 𝗦𝗣𝗔𝗠  </b>   
  
  
         
   [𝗦𝗢𝗜𝗢](https://t.me/S_OL_O7)   
  
  
           ─「 𝐷𝐸𝑃𝐿𝑂𝑌 𝑂𝑁 𝐻𝐸𝑅𝑂𝐾𝑈 」─   
  
   </h3>   
  
   <p align="center"><a href="https://dashboard.heroku.com/new?template=https://github.com/SOLOT773/STRANGER-USERBOT3.0"> <img src="https://img.shields.io/badge/Deploy%20On%20Heroku-bringle?style=for-the-badge&logo=heroku" width="220" height="38.45"/></a></p>   
   ━━━━━━━━━━━━━━━━━━━━━━   
  
   # Rᴇǫᴜɪʀᴇᴍᴇɴᴛs   
   - API_ID   
   - API_HASH   
   - PYROGRAM SESSION (V1.4)   
   - OWNER ID   
  
   ━━━━━━━━━━━━━━━━━━━━━━   
  
   # Pʏʀᴏɢʀᴀᴍ (V1.4) Sᴇssɪᴏɴ Sᴛʀɪɴɢ   
  
   - [BᴏᴛLɪɴᴋ](https://t.me/S_T_WBOT)   
  
   - Bᴏᴛ Usᴇʀɴᴀᴍᴇ - @S_T_WBOT   
  
   ━━━━━━━━━━━━━━━━━━━━━━ 
